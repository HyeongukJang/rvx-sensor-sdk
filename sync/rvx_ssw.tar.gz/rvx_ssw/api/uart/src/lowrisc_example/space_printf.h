#ifndef __ERVP_PRINTF_H__
#define __ERVP_PRINTF_H__

int printf(const char* fmt, ...);

#endif
