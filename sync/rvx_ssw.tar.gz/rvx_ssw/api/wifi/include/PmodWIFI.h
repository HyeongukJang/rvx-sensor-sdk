#include "MRF24G.h"
#include "DEIPcK.h"
#include "DEWFcK.h"

extern "C" void __cxa_pure_virtual() { while (1); } // error handler function for pure virtual functions
