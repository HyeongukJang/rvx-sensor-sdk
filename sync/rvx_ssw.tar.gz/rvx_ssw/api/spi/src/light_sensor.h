#ifndef __LIGHT_SENSOR_H__
#define __LIGHT_SENSOR_H__

void configure_light_sensor();
unsigned int read_light_sensor_value();

#endif
